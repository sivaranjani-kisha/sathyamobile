import dbConnect from "@/lib/db";
import EcomOrderInfo from "@/models/ecom_order_info";

export async function POST(req) {
  await dbConnect();

  try {
    const body = await req.json(); // Use req.json() instead of req.body in Next.js API routes

    const {
      order_id,
      email_address,
      mobile_number,
      product_id,
      price,
      order_status,
      payment_status,
      created_date,
      modified_date,
      status,
    } = body;

    // Validate required fields
    if (!order_id || !email_address || !mobile_number || !product_id || !price) {
      return Response.json({ success: false, message: "Missing required fields" }, { status: 400 });
    }

    const newOrder = new EcomOrderInfo({
      order_id,
      email_address,
      mobile_number,
      product_id,
      price,
      order_status: order_status || "pending",
      payment_status: payment_status || "unpaid",
      created_date: created_date || new Date(),
      modified_date: modified_date || new Date(),
      status: status || "active",
    });

    await newOrder.save();
    return Response.json({ success: true, message: "Order added successfully", order: newOrder }, { status: 201 });

  } catch (error) {
    return Response.json({ success: false, message: "Server error", error: error.message }, { status: 500 });
  }
}
