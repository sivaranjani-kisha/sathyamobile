"use client";
import React from "react";
import CreateStoreForm from "../../components/store/CreateStoreForm"; // adjust path as need../../components/store/CreateStoreForm

export default function CreateStorePage() {
  return (
   
      <CreateStoreForm />

  );
}
