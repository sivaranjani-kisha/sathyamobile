export default function AdminPage() {
  return (
    <div>
      <h1>Welcome to the Admin Panel</h1>
      <p>This is the main admin page.</p>
    </div>
  );
}
