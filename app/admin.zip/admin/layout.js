import AdminHeader from "../admin/components/AdminHeader";
import AdminFooter from "../admin/components/AdminFooter";

export default function AdminLayout({ children }) {
  return (
    <>
      <AdminHeader />
      <main className="min-h-screen bg-gray-100 p-4">{children}</main>
      <AdminFooter />
    </>
  );
}
