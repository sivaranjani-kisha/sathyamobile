
export default function Dashboard() {
  return <h2 className="text-center mt-10">Admin Dashboard</h2>;
}
